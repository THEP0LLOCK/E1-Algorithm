#include <stdio.h>
int main(void)
{
	char str[5][15] = {'!'};
	for (int x = 0; x < 5; x++) {
		scanf("%s", str[x]);
	}
	for (int y = 0; y < 15; y++) {
		for (int x = 0; x < 5; x++) {
			if (str[x][y] != '!') printf("%c", str[x][y]);
		}
	}
}