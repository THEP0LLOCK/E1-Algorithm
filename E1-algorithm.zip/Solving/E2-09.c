#include <stdio.h>
int main(void) 
{
	int array[100][100] = { 0 };
	int x, y;
	int count = 0;
	
	int r;
	scanf("%d", &r);
	for (int i = 0; i < r; i++) {
		scanf("%d %d", &x ,&y);
		for (int p = 0; p < 10; p++) {
			for (int q = 0; q < 10; q++) {
				array[p + x][q + y] = 1;
			}
		}
	}
	for (int p = 0;p < 100;p++){
		for (int q = 0;q < 100;q++){
			if (array[p][q] == 1) count++;
		}
	}
	printf("%d", count);



}