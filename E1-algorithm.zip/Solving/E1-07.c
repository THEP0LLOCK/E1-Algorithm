#include <stdio.h>
int main(void)
{
	int array[4];
	int count = 0;
	char result[3];
	for (int i = 0;i < 3;i++){
		for (int i = 0; i < 4; i++) {
			scanf("%d", &array[i]);
		}
		for (int i = 0; i < 4; i++) {
			if (array[i] == 0) count++;
		}
		if (count == 0) count = 5;
		printf("%c", count + 64);
		count = 0;
	}

}