#include <stdio.h>
int main(void)
{
	int n, p, i = 0,j,var = 0;
	int array[100];
	scanf("%d %d", &n, &p);
	var = n;
	while (1) {
		var = (var * n) % p;
		for (j = 0; j < i; j++) {
			if (array[j] == array[i]) break; 
		}
		if (j != i)
			break;
		i++;
		array[i] = var;
	}
	printf("%d", i-j);

	return 0;
}