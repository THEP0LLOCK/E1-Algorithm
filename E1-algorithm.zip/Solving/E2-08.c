#include <stdio.h>
int main(void)
{
	//�Ǻ���ġ?
	int d; //3<=d<=30
	int k;
	int array[30];

	scanf("%d %d", &d, &k);//5,8
	array[d] = k;//array[5] = 8
	int i;
	for (i = 1; i < k - 1; i++) { //1~4
		array[d - 1] = i; //4
		for (int t = d-2; t > 0; t--) {
			array[t] = array[t+2]-array[t+1];
		}
		if (array[1] > 0 && array[1] <= array[2]) {
			printf("%d\n%d", array[1], array[2]);
			break;
		}
	}




}