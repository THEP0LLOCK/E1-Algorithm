#include <stdio.h>
int main(void)
{
	int array[9];
	int max = 0;
	int line = 0;
	for (int i = 0; i < 9; i++) {
		scanf("%d", &array[i]);
	}
	for (int i = 0; i < 9; i++) {
		if (max < array[i]) {
			max = array[i];
			line = i+1;
		}
	}
	printf("%d\n%d",max,line);
}