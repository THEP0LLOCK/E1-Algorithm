#include <stdio.h>
int main(void)
{
	int num[100000];
	int r;

	int l=0, s=0,m=0;

	scanf("%d", &r);
	for (int i = 0; i < r; i++) {
		scanf("%d", &num[i]);
	}

	for (int i = 0; i < r; i++) {
		if (num[i] > num[i + 1]) {
			l++;
			if (s > m) {
				m = s;
			}
			s = 0;
		}
		else if (num[i] < num[i + 1]) {
			s++;
			if (l > m) {
				m = l;
			}
			l = 0;
		}
		else {
			l++;
			s++;
			if (l > m) {
				m = l;
			}
			if (s > m) {
				m = s;
			}
		}
	}

	printf("%d", ++m);

}