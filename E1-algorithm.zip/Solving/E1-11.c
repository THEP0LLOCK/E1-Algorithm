#include <stdio.h>
int main(void)
{
	int array[5];
	int sum = 0;
	for (int i = 0; i < 5; i++) {
		scanf("%d", &array[i]);
		sum += array[i];
	}
	for(int j=0;j<5;j++)
	for (int i = 0; i < 4; i++) {
		if (array[i] > array[i+1]) {
			int tmp;
			tmp = array[i];
			array[i] = array[i + 1];
			array[i + 1] = tmp;
		}
	}
	printf("%d\n%d", sum/5, array[3]);
}