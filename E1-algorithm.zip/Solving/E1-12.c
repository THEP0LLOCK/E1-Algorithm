#include <stdio.h>
int main(void)
{
	int array[7];
	for (int i = 0; i < 7; i++) {
		scanf("%d", &array[i]);
	}
	for (int j = 0; j < 7; j++)
		for (int i = 0; i < 6; i++) {
			if (array[i] > array[i + 1]) {
				int tmp;
				tmp = array[i];
				array[i] = array[i + 1];
				array[i + 1] = tmp;
			}
		}
	printf("%d\n%d",array[6], array[5]);
}