#include <stdio.h>
int main(void)
{
	int p, q, r, c = 0;
	scanf("%d %d %d", &p, &q, &r);
	int ctrl = 1;
	int x = 1, y = 0;


	while(1) {
		for (int i = 0; i < q; i++) {
			y += ctrl;
			c++;
			if (c == r) break;
		}
		if (c == r) break;
		for (int i = 0; i < p - 1; i++) {
			x += ctrl;
			c++;
			if (c == r) break;
		}
		if (c == r) break;
		ctrl *= -1;
		p--;
		q--;
	}

	if (r <= p * q) printf("%d %d", x, y);
	else printf(0);
}