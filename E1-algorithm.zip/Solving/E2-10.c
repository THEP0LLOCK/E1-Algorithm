#include <stdio.h>
int main(void)
{
	int a,b,c;
	int num;
	int count = 0;
	int arr[10] = { 0 }; //1,7,0,3,7,3,0,0
		scanf("%d %d %d", &a,&b,&c);
	num = a * b * c;
	while (1) {
		arr[num % 10]++;
		num /= 10;
		if (num == 0) break;
	}

	for (int i = 0; i < 10; i++) {
		for (int t = 0; t < 10; t ++) {
			if (arr[t] == i) count++;
		}
		printf("%d\n", count);
		count = 0;
	}





}