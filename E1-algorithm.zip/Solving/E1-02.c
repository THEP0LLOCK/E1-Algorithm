#include <stdio.h>
int main(void)
{
	//300�� * 4 ,1000 + 200
	//250�� * 2 ,140
	int k;
	int n;
	int m;
	scanf("%d", &k);
	scanf("%d", &n);
	scanf("%d", &m);
	printf("%d",k*n-m);





}