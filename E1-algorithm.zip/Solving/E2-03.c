#include <stdio.h>
int main(void)
{
	int r;
	int array1[50],array2[50];
	//�Է� p
	scanf("%d", &r);
	for (int i = 0; i < r; i++) {
		scanf("%d %d",&array1[i],&array2[i]);
	}
	
	for (int l = 0; l < r; l++) {
		int c = 1;
		for (int i = 0; i < r; i++) {
			if (array1[l] < array1[i] && array2[l] < array2[i]) {
				c++;
			}
		}
		printf("%d ", c);
	}

	return 0;
}