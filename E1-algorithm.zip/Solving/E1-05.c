#include <stdio.h>
int main(void) 
{
	int a;
	int b;
	int result = 0;
	int max = 0;
	for (int i = 0; i < 4; i++) {
		scanf("%d %d", &a, &b);
		result -= a;
		result += b;
//		printf("[%d]", result);
		if (result > max) max = result;
	}
	printf("%d", max);
}