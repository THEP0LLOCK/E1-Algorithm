#include <stdio.h>
int main(void)
{
	int a, b;
	scanf("%d %d", &a, &b);
	int count = b;


	for (int i = 1; i < a; i++) {
		if (a % i == 0) b--;
		
		if (b == 0) {
			printf("%d", i);
			break;
		}
	}
	if (b != 0) printf("0");
}