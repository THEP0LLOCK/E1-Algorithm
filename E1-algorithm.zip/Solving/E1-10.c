#include <stdio.h>
int main(void)
{
	int array[7];
	int sum = 0;
	int min = 100;
	for (int i = 0; i < 7; i++) {
		scanf("%d", &array[i]);
	}
	for (int i = 0; i < 7; i++) {
		if (array[i] % 2 != 0) sum += array[i];
		if (array[i] % 2 != 0 && array[i] < min) min = array[i];
	}
	printf("%d\n%d",sum,min);
}