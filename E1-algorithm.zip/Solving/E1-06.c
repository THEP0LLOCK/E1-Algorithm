#include <stdio.h>
int main(void)
{
	int array[5];
	int tmp = 0;
	for (int i = 0; i < 5; i++) {
		scanf("%d",&array[i]);
	}
	for (int i = 0; i < 5; i++){
		tmp += array[i] * array[i];
	}
	printf("%d", tmp % 10);

}